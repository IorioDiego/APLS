#!/bin/bash


# +++++++++++++++ENCABEZADO+++++++++++++++++++++++++++
# Nombre script: Ejercicio2.sh
# Trabajo Práctico Nro. 1 (GRUPAL)
# Ejercicio: 6
# Integrantes:
  #  Cardozo Emanuel                    35000234
  #  Iorio Diego                        40730349
  #  Paz Zarate Evelyn  Jessica         37039295
  #  Perez Lucas Daniel                 39656325
  #  Ramos Marcos                       35896637
# Nro entrega: Primera Entrega
# +++++++++++++++FIN ENCABEZADO+++++++++++++++++++++++


mostrarAyuda(){
    echo "Descripcion: ..........."
    echo "El Script moverá elementos a la Papelera de reciclaje. "
    echo ""
    echo "Las opciones disponibles son las siguientes: "
    echo ""
    echo "LISTAR"
    echo "-l : Se listan todos los archivos dentro de la papelera de reciclaje. "
    echo "VACIAR PAPELERA"
    echo "-e: Se vacia la papelera de reciclaje, eliminando permanentemente los archivos que la papelera contenga."
    echo "RECUPERACION DE ARCHIVOS"
    echo "-r: Se podrán recuperar archivos enviandolos a la ruta de origen. Se debe indicar el nombre del archivo. Por Ejemplo $0 -r nombreArchivo"
    echo "AYUDA"
    echo "-h: Mostrar ayuda"
    echo "ENVIAR ARCHIVO A LA PAPELERA"
    echo "Para enviar un archivo a la papelera de reciclaje se debe indicar el nombre del elemento a mover. Por ejemplo $0 nombreFArchivo"
}

HELP=0
LISTADO=0
RECUPERAR=0
VACIAR=0
ENVIAR=0
PATH_PAPELERA="/tmp/PapeleraDeReciclaje"
pathUser=""


descomprimirPapelera(){
    cd ~ 
   pathUser=$PWD
    if [[ -f "$PWD/PapeleraDeReciclaje.zip" ]]; then
      unzip -q "$PWD/PapeleraDeReciclaje.zip" -d $PATH_PAPELERA
    else 
      mkdir "$PATH_PAPELERA"
      mkdir "$PATH_PAPELERA/Archivos"
      touch "$PATH_PAPELERA/ListadoDeArchivosEnLaPapelera.txt"
     
      cd $PATH_PAPELERA
      zip -q "$pathUser/PapeleraDeReciclaje.zip" *
      rm -r $PATH_PAPELERA
      cd $pathUser
unzip -q "$PWD/PapeleraDeReciclaje.zip" -d $PATH_PAPELERA
    fi  
}


listarElementosEnPapelera(){  
    descomprimirPapelera
    listaArchivos="$PATH_PAPELERA/ListadoDeArchivosEnLaPapelera.txt"

    if [[ $(cat "$listaArchivos" | wc -l) > 0 ]]; then
        echo "LISTADO DE LOS ELEMENTOS EN LA PAPELERA"
        echo ""
        #obtengo el nombre y la ruta de todos los archivos
        nom=`awk 'BEGIN{FS=":"} {print $2 "       " $3}' $listaArchivos`
        echo "$nom" 
    else 
        echo "No hay elementos en la papelera"
    fi
    
    rm -r $PATH_PAPELERA
    
}
vaciarPapelera(){
    cd ~
    rm "$PWD/PapeleraDeReciclaje.zip"
    echo "SE HAN ELIMINADO TODOS LOS ARCHIVOS DE LA PAPELERA DE RECICLAJE"
}

enviarFicheroAPapelera(){
    if [[ -f $1 ]]; then
        descomprimirPapelera
        lista="$PATH_PAPELERA/ListadoDeArchivosEnLaPapelera.txt"
        cd $PATH_PAPELERA
        #obtengo la columna de ids y voy contando la cantidad de elementos que hay
        nombreNuevo=`awk 'BEGIN{FS=":"} {print $1}' $lista`
        contador=0
        for n in ${nombreNuevo[@]}
        do 
        contador="$(($n+1))"
        done
        
        #si el nombre del archivo viene con barra, lo separo. Si no viene con barra esta en el mismo directorio
         if [[ "$1" == *"/"* ]]; then
            ruta="${1%/*}/"
            nombre="${1##*/}"
        else
            nombre=$1
            ruta="$pathUser/"
                
        fi  
        if [[ $nombreNuevo ]]; then
            mv $ruta$nombre "$PATH_PAPELERA/Archivos/$contador"
            echo "$contador:$nombre:$ruta" >> $lista
        else #solo para la primera vez, cuando se crea el zip
            mv $ruta$nombre "$PATH_PAPELERA/Archivos/1" 
            echo "1:$nombre:$ruta" >> $lista
             
        fi
   
        rm -f "$pathUser/PapeleraDeReciclaje.zip"
        zip -q -r "$pathUser/PapeleraDeReciclaje.zip" *
        rm -r $PATH_PAPELERA
        echo "SE HA ENVIADO $1 A LA PAPELERA DE RECICLAJE"
    else 
     echo "No se ha encontrado el archivo $1 No se enviará a la papelera"
    fi
}

restaurarFichero(){
    listadoAMostrar=()
    descomprimirPapelera
    listaArchivos="$PATH_PAPELERA/ListadoDeArchivosEnLaPapelera.txt"
    #se verifica que hayan archivos en la papelera y se busca el nombre ingresado por parametro
    if [[ $(cat "$listaArchivos" | wc -l) > 0 ]]; then
        listaConPath=`awk 'BEGIN{FS=":"} {print $3 $2}' $listaArchivos`
        #echo  "${listaConPath[@]}"
        if [[ "$1" == *"/"* ]]; then #identifico si incluye el path
          # echo "Ingrese solo el nombre del archivo"
            exit 1
        
        else 
            indice=0
            for linea in ${listaConPath[@]} 
            do
                indice="$((indice+1))"
                if [[ "$linea" == *"/"* ]]; then #separo la ruta y el nombre que vienen desde la papelera
                    ruta="${linea%/*}/"
                    nombre="${linea##*/}"                   
                fi

                if [[ "$1" == "$nombre" ]]; then
                    listadoAMostrar+=("$indice - nombre: $nombre - ruta: $ruta")
                fi
            done
            #si hay mas de un archivo con el mismo nombre preguntar cual se quiere borrar
            if [[ ${#listadoAMostrar[*]} > 1 ]]; then
                echo " Cual archivo quiere restaurar?"
                echo ${listadoAMostrar[*]}
                read valor 
                valor="$((valor-1))"
               
                ruta="${listadoAMostrar[$valor]##*'- ruta: '}"
                id="${listadoAMostrar[$valor]%' - nombre:'*}"
                
                #restaurar archivo
                mv "$PATH_PAPELERA/Archivos/$id" "$ruta$1"
                sed -i "$id d" "$listaArchivos"
                                
            elif [[ ${#listadoAMostrar[*]} == 1  ]]; then
                ruta="${listadoAMostrar##*'- ruta: '}"
                id="${listadoAMostrar%' - nombre:'*}"
                
                #restaurar archivo
                mv "$PATH_PAPELERA/Archivos/$id" "$ruta$1"
                sed -i "$id d" "$listaArchivos"
            else 
                echo "No se ha enconrado el archivo en la papelera"

            fi
        fi
    
    else
        echo "no hay elementos para restaurar"
        rm -f "$pathUser/PapeleraDeReciclaje.zip"
        cd $PATH_PAPELERA
        zip -q -r "$pathUser/PapeleraDeReciclaje.zip" *
        rm -r $PATH_PAPELERA
        exit 1
    fi
    #comprimir
    rm -f "$pathUser/PapeleraDeReciclaje.zip"
    cd $PATH_PAPELERA
    zip -q -r "$pathUser/PapeleraDeReciclaje.zip" *
    rm -r $PATH_PAPELERA
    
    
}



#se verifica que no hayan parametros de mas
if test $# -lt 3; then
    if test "$1" == "-r" && test $# -lt 2 ; then 
        mostrarAyuda
        exit 1
    fi
else 
    mostrarAyuda
    exit 1

fi


while getopts hler: option; do
    case $option in 
        h)
            HELP=1
            ;;
        l)
            LISTADO=1
            ;;
        r) RECUPERAR=$OPTARG
            ;;
        e)
            VACIAR=1
            ;;
    esac
done


if test $HELP -eq 1; then
    mostrarAyuda
    exit 0

elif test $LISTADO -eq 1; then
    listarElementosEnPapelera
    exit 0

elif test $VACIAR -eq 1; then
    vaciarPapelera
    exit 0

elif test "$RECUPERAR" == "$2"; then
    restaurarFichero "$2"
    exit 0

else 
    if [[ -z $1 ]]
     then
        echo "Debe enviar el archivo que sea mandar a la papelera"
         mostrarAyuda
        exit 1;
     fi
    pathArchivo=$(readlink -e $1)
    enviarFicheroAPapelera "$pathArchivo"
    exit 0
fi
