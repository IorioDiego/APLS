class Materia {
    $materia
    $nota

    Materia($cod,$nota) {
        $this.materia = $cod 
        $this.nota = $nota
    }
    
}